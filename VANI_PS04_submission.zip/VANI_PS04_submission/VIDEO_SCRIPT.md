# Demo video script: VANI per-seller personas (PS04)

**Length:** about 6½ minutes. The narration is about 850 words at a relaxed pace.

**Format:**
- **SAY** is your narration.
- **SHOW** is what is on screen.
- **YOU (as seller)** is what you say on the live call. VANI's replies will vary a little, which is fine: it shows the switches are live, not scripted.

## Before you press record

1. Top up the Sarvam credits.
2. Start the server: `.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000`
3. Keep the cloudflared tunnel running. If its address changed, update the three Sarvam tools.
4. Open these browser tabs:
   - the slide (`slide/one_slide.pdf`);
   - http://127.0.0.1:8000/docs, already **Authorized** with your `API_TOKEN`;
   - the Sarvam dashboard for agent `sulabh-im-80199a3e-82ea`.
5. Keep VS Code open on `outputs/switch_log.md` and `outputs/persona_specs/6299.md`.
6. Set up the test calls to your verified phone number, with `glid` = **6299** for call 1 and **95487** for call 2.
7. Do one dry run without recording.

---

## Scene 1: The problem (0:00–0:40)

**SHOW:** the one slide, full screen.

**SAY:**
> Hi, we're team Beyond Binary. This is our solution for PS04, Persona Design.
> Today VANI talks to every seller in one voice and one style, for the whole call. But sellers differ. A busy trader in Delhi, a manufacturer in Guwahati who asked for a callback, a large firm in Pune: each needs a different approach. And when a seller gets irritated or confused mid-call, VANI keeps going the same way.
> We built a persona for every seller before the call, from their own data, and VANI adapts it live during the call.

---

## Scene 2: How it works (0:40–1:20)

**SHOW:** the workflow column on the slide. Point at steps 1 to 6 as you speak.

**SAY:**
> We loaded the full PS07 dataset: about 1.5 lakh sellers, 3.4 lakh past calls and 1.4 lakh transcript turns.
> From the past calls we mined what actually fixes meetings. For example, sellers whose answered calls average under 20 seconds fix only half a percent of meetings, against 11.5% overall. Those sellers need a brisk, short call.
> Our persona engine sets the voice, language, tone and conversation plan for each seller. Every choice comes with a reason, the data behind it and a confidence level.
> Before the first word, the Sarvam agent fetches that persona through an API tool. During the call it watches for five signals: frustration, confusion, rush, interest and a language switch. It changes how it speaks, never the facts or prices, and logs each switch.

---

## Scene 3: Two sellers, two personas (1:20–2:30)

**SHOW:** Swagger at `/docs`.
1. Open **POST /api/v1/supplier/persona**, click **Try it out**, send `{"glid": 6299}` and click **Execute**.
2. Scroll to `persona.spec.voice` and `language`, then `history_insights`.
3. Change the body to `{"glid": 95487}` and click **Execute**.

**SAY (on 6299):**
> First seller: MS International, a trader in New Delhi. Our engine marks them "fatigued and sceptical". Their last four calls were all "not interested", each under 15 seconds, and all within three days.
> So VANI goes brisk, warm and low-pressure. The call opens in Hindi and is ready to switch to English. Most importantly, at the first sign of irritation VANI apologises and ends the call. No pushing.
> See the reason and the evidence on each choice: here, "calls under 20 seconds: 0.5% meetings against an 11.5% baseline", from more than 45,000 sellers.

**SAY (on 95487):**
> Second seller: Kencraft and Allied Industries in Guwahati. A completely different persona: "time-pressed". They asked for a callback on 16 September, so VANI opens by honouring that promise. It's ready to switch to Bengali, and it suggests the TrustSEAL Pro package that fits their turnover, with the listed price only.
> Same engine, same data fields, clearly different personas. This works with no LLM at all: it is deterministic and every choice is explainable.

---

## Scene 4: Live call 1, seller 6299, frustration (2:30–3:40)

**SHOW:** start the Sarvam test call with `glid = 6299`. Put the phone on speaker, close to the mic.

**SAY (before dialling):**
> Let's call MS International. Remember, this seller has little patience.

| Who | Line |
|---|---|
| VANI | *हेलो, क्या आप MS International से बोल रहे हैं?* |
| **YOU** | Haan ji, bol raha hoon. Kaun? |
| VANI | Introduces itself as VANI from IndiaMART, about your listing, and asks one short question. |
| **YOU** | Yaar roz roz IndiaMART se call aata hai, time waste karte ho. |
| VANI | Apologises, says IndiaMART will keep calls to a minimum, and ends the call. |

**SAY (after the call):**
> The greeting used the seller's own business name, fetched before the call. Then, at the first sign of irritation, VANI did not pitch. It apologised and closed, exactly as this seller's persona required.

**SHOW:** Swagger, **GET /api/v1/switch-log** with `glid` = 6299. Point at the new `frustration` row and the seller's words.

> And here is the switch, logged live: the signal, the change made, the reason and the seller's exact words.

---

## Scene 5: Live call 2, seller 95487, rush, language and interest (3:40–5:10)

**SHOW:** start the test call with `glid = 95487`.

**SAY (before dialling):**
> Now Kencraft in Guwahati. This time I'll be busy, then switch to English, then ask the price.

| Who | Line |
|---|---|
| VANI | *हेलो, क्या आप Kencraft & Allied Industries से बोल रहे हैं?* |
| **YOU** | Haan, bolo. |
| VANI | Introduces itself and reminds you that you asked for a callback on 16 September. |
| **YOU** | Busy hoon abhi, jaldi boliye. |
| VANI | **Rush:** no explanation, one quick question, such as a meeting tomorrow at eleven or four. |
| **YOU** | Actually, can we talk in English? What does this package cost? |
| VANI | **Language switch and interest:** continues in English and says "TrustSEAL Pro, sixty thousand rupees for one year", plus one benefit, then offers two meeting times. |
| **YOU** | OK, tomorrow at eleven is fine. |
| VANI | Repeats the time and closes politely. |

**SAY (after the call):**
> Three live switches in one call. When I said I was busy, VANI cut to one short question. When I spoke English, it followed me. When I asked the price, it quoted the official listed price, in words, with no discount and no invented offer.

---

## Scene 6: Evidence, safety and robustness (5:10–6:15)

**SHOW:** Swagger, **GET /api/v1/calls/{call_ref}** for call 2 (the `call_ref` is in the switch log).

**SAY:**
> Every call has a unique ID. In one view we can see the persona variables VANI received before the call, every live switch it made, and the outcome after the call: here, a meeting fixed for tomorrow at eleven.

**SHOW:** `outputs/switch_log.md` in VS Code.

> Across our test calls we logged 26 live switches, covering all five required signals.

**SHOW:** Swagger, **POST /api/v1/campaign/dial-check** with `{"glids": [6299, 95487]}`. Then the terminal running `python -m pytest -q`, showing it pass.

> Safety is built in. Sellers who asked not to be called are blocked before dialling: 1,178 of them in this data. If VANI is ever asked whether it is a bot, it answers truthfully. Prices always come from IndiaMART's official page, spoken in words generated by code, because we found the LLM misreads digits. And 106 automated tests cover data edge cases, prompt injection, LLM failures and access control.

---

## Scene 7: Close (6:15–6:40)

**SHOW:** the slide again.

**SAY:**
> To sum up: one persona per seller, built from their data and backed by past-call evidence. VANI adapts live when the seller is frustrated, confused, rushed or interested, or switches language, and every switch is logged.
> The code, persona specs, switch log and our build journey in skills.md are in the submission folder. Thank you.

---

## Backup plans

| If this happens | Do this |
|---|---|
| VANI says the English greeting for 6299 or 95487 | Say: *"For sellers without a name on record VANI uses a general greeting."* Keep going and tell us afterwards; the greeting may be playing before the seller lookup finishes. |
| A switch doesn't fire | Repeat the cue more clearly, for example *"Bahut busy hoon, jaldi boliye"*, or skip it and show the logged switches in `outputs/switch_log.md`. |
| The call drops or credits run out | Show the earlier logged calls through `GET /api/v1/calls` and the switch log. |
| Swagger returns 403 | Click **Authorize** again and paste the token. |
| You need a confusion example | On call 2, say *"Kya matlab? Samajh nahi aaya"*. VANI restates simply and logs `confusion`. |
